package com.example.meetsdk;

import android.app.Application;

import com.moxtra.sdk.MXAccountManager;
import com.moxtra.sdk.MXSDKException.InvalidParameter;

public class MyApplication extends Application {

    private String gcmRegId;
    private MXAccountManager mAcctMgr;

    @Override
    public void onCreate(){
        super.onCreate();
        //this.registerGCM();
        initAccountManager();
    }

    private void initAccountManager(){
        if (mAcctMgr == null) {
            try {
                mAcctMgr = MXAccountManager.createInstance(this);
            } catch (InvalidParameter e) {
                e.printStackTrace();
            }
        }
    }

    public MXAccountManager getAccountManager(){
        return mAcctMgr;
    }

    public void setGCMRegId(String regId){
        gcmRegId = regId;
//        if(mAcctMgr != null){
//            mAcctMgr.updateNotificationToken(gcmRegId);
//        }
    }

    public String getNotificationId(){
        return gcmRegId;
    }

    @Override
    public void onTerminate(){
        super.onTerminate();
    }
}

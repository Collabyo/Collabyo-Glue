package com.example.meetsdk;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

/**
 * Created by Breeze on 14/10/22.
 */
public class InviteParticipantsActivity extends FragmentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_invite_participants);
    }
}
